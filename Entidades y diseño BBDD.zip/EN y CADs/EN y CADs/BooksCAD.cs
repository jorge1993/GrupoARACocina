﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebPrueba
{
    public class BooksCAD
    {
        //Ctor without parameters
        public BooksCAD()
        {
        }


        //Function to add a new book
        public void insertBook(BooksEN book)
        {
        }

        //Function to remove a book
        public void deleteBook()
        {
        }

        //Modify the price of a book
        public void changePrice()
        {
        }


        /***********/
        /** DATOS **/
        /***********/

        private Database db;
        private BooksEN booksEN;

    }
}
