using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Finisar.SQLite;

namespace WebPrueba
{
    public class UtensilsCAD
    {
        private Database db;
        
        public UtensilsCAD()
        {

        }

        public void INSERT(UtensilsEN e)
        {

        }

        public UtensilsEN READ(int cod)
        {
            return (null);
        }

        public void UPDATE(UtensilsEN update)
        {

        }
        
        public void DELETE(int cod)
        {

        }
    }
}
