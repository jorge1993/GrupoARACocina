﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Web.Controllers
{
    [HandleError]
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewData["Message"] = "La cocina de la abuela";

            return View();
        }

        public ActionResult About()
        {
            return View();
        }

        public ActionResult Contacto()
        {
            return View();
        }

        public ActionResult Recetas()
        {
            return View();
        }

        public ActionResult Libros()
        {
            return View();
        }
    }
}
