using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Finisar.SQLite;

namespace WebPrueba
{
    public class CommentsCAD
    {
        private Database db;
        
        public CommentsCAD()
        {

        }

        public void INSERT(CommentsEN e)
        {

        }

        public CommentsEN READ(int cod)
        {
            return (null);
        }

        public void UPDATE(CommentsEN update)
        {

        }
        
        public void DELETE(int cod)
        {

        }
    }
}
